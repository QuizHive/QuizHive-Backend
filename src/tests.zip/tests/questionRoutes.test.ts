import request from 'supertest';
import app from '../app'; // Your Express app
import { connectDb, disconnectDb } from '../config/db'; // Ensure you have a method for DB connection

describe('Question Routes', () => {
  beforeAll(async () => {
    await connectDb(); // Connect to the test DB before running tests
  });

  afterAll(async () => {
    await disconnectDb(); // Disconnect after tests are done
  });

  it('should create a question', async () => {
    const res = await request(app)
      .post('/api/questions')
      .send({
        question: 'What is 2 + 2?',
        options: ['3', '4', '5', '6'],
        answer: '4',
      });

    expect(res.status).toBe(201); // Expect a Created status code
    expect(res.body.question).toBe('What is 2 + 2?');
    expect(res.body.answer).toBe('4');
  });

  it('should fetch all questions', async () => {
    const res = await request(app).get('/api/questions');

    expect(res.status).toBe(200); // Expect a successful response
    expect(res.body).toBeInstanceOf(Array); // Should return an array of questions
    expect(res.body.length).toBeGreaterThan(0); // Assuming you have some test data
  });

  it('should return a single question by id', async () => {
    const res = await request(app)
      .get('/api/questions/1')
      .send();

    expect(res.status).toBe(200);
    expect(res.body.question).toBeDefined();
  });

  it('should update a question', async () => {
    const res = await request(app)
      .put('/api/questions/1')
      .send({
        question: 'What is 2 + 3?',
        options: ['4', '5', '6', '7'],
        answer: '5',
      });

    expect(res.status).toBe(200);
    expect(res.body.question).toBe('What is 2 + 3?');
  });

  it('should delete a question', async () => {
    const res = await request(app).delete('/api/questions/1');

    expect(res.status).toBe(200);
    expect(res.body.message).toBe('Question deleted successfully');
  });
});
