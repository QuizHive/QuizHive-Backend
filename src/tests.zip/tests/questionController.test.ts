import { createQuestion, getQuestions, updateQuestion, deleteQuestion } from './questionController';
import { QuestionModel } from "../src/models/Question";
import mongoose from 'mongoose';

// Mocking database operations
jest.mock('./questionSchema');

describe('Question Controller', () => {
  beforeEach(() => {
    jest.clearAllMocks(); // Clear any mocked calls between tests
  });

  it('should create a question', async () => {
    const mockCreate = jest.fn().mockResolvedValue({
      _id: mongoose.Types.ObjectId(),
      question: 'What is 2 + 2?',
      options: ['3', '4', '5', '6'],
      answer: '4',
    });
    (QuestionModel.create as jest.Mock) = mockCreate;

    const result = await createQuestion({
      question: 'What is 2 + 2?',
      options: ['3', '4', '5', '6'],
      answer: '4',
    });

    expect(mockCreate).toHaveBeenCalledTimes(1);
    expect(result.question).toBe('What is 2 + 2?');
  });

  it('should get all questions', async () => {
    const mockFind = jest.fn().mockResolvedValue([
      { question: 'What is 2 + 2?', options: ['3', '4', '5', '6'], answer: '4' },
    ]);
    (QuestionModel.find as jest.Mock) = mockFind;

    const result = await getQuestions();
    expect(mockFind).toHaveBeenCalledTimes(1);
    expect(result).toHaveLength(1); // We expect 1 question to be returned
  });

  it('should update a question', async () => {
    const mockFindOneAndUpdate = jest.fn().mockResolvedValue({
      _id: mongoose.Types.ObjectId(),
      question: 'What is 2 + 3?',
      options: ['4', '5', '6', '7'],
      answer: '5',
    });
    (QuestionModel.findOneAndUpdate as jest.Mock) = mockFindOneAndUpdate;

    const result = await updateQuestion('1', {
      question: 'What is 2 + 3?',
      options: ['4', '5', '6', '7'],
      answer: '5',
    });

    expect(mockFindOneAndUpdate).toHaveBeenCalledTimes(1);
    expect(result.question).toBe('What is 2 + 3?');
  });

  it('should delete a question', async () => {
    const mockDeleteOne = jest.fn().mockResolvedValue({ deletedCount: 1 });
    (QuestionModel.deleteOne as jest.Mock) = mockDeleteOne;

    const result = await deleteQuestion('1');

    expect(mockDeleteOne).toHaveBeenCalledTimes(1);
    expect(result.message).toBe('Question deleted successfully');
  });
});