import { QuestionModel} from '../models/Question';

describe('Question Schema Validation', () => {
  it('should validate question data correctly', async () => {
    const validQuestion = new QuestionModel({
      question: 'What is 2 + 2?',
      options: ['3', '4', '5', '6'],
      answer: '4',
    });

    const error = validQuestion.validateSync();
    expect(error).toBeUndefined(); // Validation should pass
  });

  it('should fail validation with missing answer', async () => {
    const invalidQuestion = new QuestionModel({
      question: 'What is 2 + 2?',
      options: ['3', '4', '5', '6'],
    });

    const error = invalidQuestion.validateSync();
    expect(error).toBeDefined(); // Should have validation error
    expect(error.errors.answer).toBeDefined();
  });

  it('should fail validation with incorrect options', async () => {
    const invalidQuestion = new QuestionModel({
      question: 'What is 2 + 2?',
      options: ['3', '4'], // Less than 4 options
      answer: '4',
    });

    const error = invalidQuestion.validateSync();
    expect(error).toBeDefined(); // Should have validation error
    expect(error.errors.options).toBeDefined();
  });
});
