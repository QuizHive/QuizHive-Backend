import dotenv from "dotenv";
import mongoose from "mongoose";
import initConnection from "../utils/database";
import questionService from "../services/questionService";

dotenv.config();

// Increase Jest timeout to ensure database operations complete
jest.setTimeout(30000);

describe("Question and Category Service Tests", () => {
    let categoryId: string;
    let questionId: string;

    // Initialize MongoDB connection before all tests
    beforeAll(async () => {
        const dbUrl = process.env.DB_URL || "mongodb://localhost:27017/quizhive";
        const options = {
            minPoolSize: 2,
            maxPoolSize: 5,
        };
        await initConnection(dbUrl, options);
    });

    // Close MongoDB connection after all tests
    afterAll(async () => {
        await mongoose.connection.close();
    });

    it("should create a category", async () => {
        const category = await questionService.createCategory(
            "General Knowledge", // Matches `categoryName` in schema
            "Questions about general knowledge"
        );
        categoryId = category._id.toString();
        console.log("Created Category:", category);

        expect(category.categoryName).toBe("General Knowledge");
        expect(category.description).toBe("Questions about general knowledge");
    });

    it("should create a question", async () => {
        const question = await questionService.createQuestion({
            questionText: "What is the capital of France?",
            options: ["Paris", "Berlin", "Madrid"],
            correct: 0, // Correct index for "Paris"
            category: categoryId, // Linking to the created category
            difficulty: 2, // Medium difficulty
        });

        questionId = question._id.toString();
        console.log("Created Question:", question);

        expect(question.questionText).toBe("What is the capital of France?");
        expect(question.options).toEqual(["Paris", "Berlin", "Madrid"]);
        expect(question.correct).toBe(0);
        expect(question.category.toString()).toBe(categoryId);
        expect(question.difficulty).toBe(2);
    });

    it("should retrieve all questions", async () => {
        const questions = await questionService.getQuestions({ category: categoryId });
        console.log("Retrieved Questions:", questions);

        expect(questions.length).toBeGreaterThan(0);
        expect(questions[0].questionText).toBe("What is the capital of France?");
    });

    it("should solve a question correctly", async () => {
        const solveResult = await questionService.solveQuestion("mockUserId", questionId, 0); // Correct index
        console.log("Solve Result (Correct):", solveResult);

        expect(solveResult.correct).toBe(true);
    });

    it("should solve a question incorrectly", async () => {
        const solveResult = await questionService.solveQuestion("mockUserId", questionId, 1); // Incorrect index
        console.log("Solve Result (Incorrect):", solveResult);

        expect(solveResult.correct).toBe(false);
    });

    it("should delete the question", async () => {
        const deletedQuestion = await questionService.deleteQuestion(questionId);
        console.log("Deleted Question:", deletedQuestion);

        expect(deletedQuestion).not.toBeNull();
    });

    it("should delete the category", async () => {
        const deletedCategory = await questionService.deleteCategory(categoryId);
        console.log("Deleted Category:", deletedCategory);

        expect(deletedCategory).not.toBeNull();
    });
});
